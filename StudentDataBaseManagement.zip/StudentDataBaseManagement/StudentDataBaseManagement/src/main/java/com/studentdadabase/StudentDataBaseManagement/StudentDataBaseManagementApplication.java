package com.studentdadabase.StudentDataBaseManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentDataBaseManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentDataBaseManagementApplication.class, args);
	}

}
