package com.studentdadabase.StudentDataBaseManagement.exceptions;

public class StudentNotFoundByPhno extends RuntimeException {
	
	private String message;

	public StudentNotFoundByPhno(String message) {
		super();
		this.message = message;
	}
	public String getMessage()
	{
		return message;
	}

}
