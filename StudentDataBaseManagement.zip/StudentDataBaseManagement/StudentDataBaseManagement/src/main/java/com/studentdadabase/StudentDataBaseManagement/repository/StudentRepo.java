package com.studentdadabase.StudentDataBaseManagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.studentdadabase.StudentDataBaseManagement.entity.Student;

public interface StudentRepo  extends CrudRepository<Student, Integer>{
		public Student findByStudentEmail(String email);
		
		public  Student findByStudentPhno(long phno);
		
		
		@Query("select s.studentEmail from Student s where s.studentGrade=?1")
		public List<String> getAllEmailByGrade(String grade);		
}
