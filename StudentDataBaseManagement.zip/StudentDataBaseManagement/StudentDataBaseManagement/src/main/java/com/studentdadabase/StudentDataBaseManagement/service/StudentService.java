package com.studentdadabase.StudentDataBaseManagement.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.studentdadabase.StudentDataBaseManagement.dto.StudentRequest;
import com.studentdadabase.StudentDataBaseManagement.dto.StudentResponse;
import com.studentdadabase.StudentDataBaseManagement.entity.Student;
import com.studnetdatabase.StudentDataBaseManagement.utilll.ResponseStructure;

public interface StudentService {
	
	public ResponseEntity<ResponseStructure<StudentResponse>> saveData(StudentRequest student);
	public ResponseEntity<ResponseStructure<StudentResponse>> updateData(StudentRequest student , int studentId);
	public ResponseEntity<ResponseStructure<StudentResponse>> deleteData(int studentId);
	public ResponseEntity<ResponseStructure<StudentResponse>> findData(int studentId);
	public ResponseEntity<ResponseStructure<List<StudentResponse>>> findAllData();
	public ResponseEntity<ResponseStructure<StudentResponse>> findByEmail(String studentEamail);
	public ResponseEntity<ResponseStructure<StudentResponse>> findByPhNo(long phNo);
	public ResponseEntity<ResponseStructure<List<String>>> findEmailByGrade(String grade);

}
