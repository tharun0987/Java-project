package com.studentdadabase.StudentDataBaseManagement.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

public class StudentRequest {
	
	private String studentGrade;
	private String studentName;
	private String studentEmail;
	@Min(value = 6000000000l,message = "Phone Number Cannot start below `6`..!!")
	@Max(value = 9999999999l, message = "Phone Number cannot be above `99999999999` !!")
	private long studentPhno;
	private String studentPassword;

	
	

	public String getStudentPassword() {
		return studentPassword;
	}
	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}
	public String getStudentGrade() {
		return studentGrade;
	}
	public void setStudentGrade(String studentGrade) {
		this.studentGrade = studentGrade;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentEmail() {
		return studentEmail;
	}
	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}
	public long getStudentPhno() {
		return studentPhno;
	}
	public void setStudentPhno(long studentPhno) {
		this.studentPhno = studentPhno;
	}
	
	
}
