package com.studentdadabase.StudentDataBaseManagement.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.studentdadabase.StudentDataBaseManagement.dto.StudentRequest;
import com.studentdadabase.StudentDataBaseManagement.dto.StudentResponse;
import com.studentdadabase.StudentDataBaseManagement.entity.Student;
import com.studentdadabase.StudentDataBaseManagement.exceptions.NoEmailFouundOnThisGrade;
import com.studentdadabase.StudentDataBaseManagement.exceptions.StudentNotFoundByEmail;
import com.studentdadabase.StudentDataBaseManagement.exceptions.StudentNotFoundByIdException;
import com.studentdadabase.StudentDataBaseManagement.exceptions.StudentNotFoundByPhno;
import com.studentdadabase.StudentDataBaseManagement.repository.StudentRepo;
import com.studentdadabase.StudentDataBaseManagement.service.StudentService;
import com.studnetdatabase.StudentDataBaseManagement.utilll.ResponseStructure;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	StudentRepo repo;


	@Override
	public ResponseEntity<ResponseStructure<StudentResponse>> saveData(StudentRequest studentRequest) {
		
		Student student = new Student();
		student.setStudentName(studentRequest.getStudentName());
		student.setStudentEmail(studentRequest.getStudentEmail());
		student.setStudentGrade(studentRequest.getStudentGrade());
		student.setStudentPhno(studentRequest.getStudentPhno());
		student.setStudentPassword(studentRequest.getStudentPassword());
		
		Student student2 = repo.save(student);// will have the data after saving it to the database.
		
		StudentResponse response= new StudentResponse();
		response.setId(student2.getId());
		response.setStudentGrade(student2.getStudentGrade());
		response.setStudentName(student2.getStudentName());		
		
		ResponseStructure<StudentResponse> structure =  new ResponseStructure<StudentResponse>();
		structure.setStatus(HttpStatus.CREATED.value());
		structure.setMessage("Student Data Saved Successfully..!!");
		structure.setData(response);

		return new ResponseEntity<ResponseStructure<StudentResponse>>(structure,HttpStatus.CREATED);
	}

	@Override
	public ResponseEntity<ResponseStructure<StudentResponse>> updateData(StudentRequest studentRequest, int studentId) {
		Optional<Student> optional = repo.findById(studentId);
		ResponseStructure<StudentResponse> structure = new ResponseStructure<StudentResponse>();;
		if(optional.isPresent())
		{
			
			Student student = new Student();
			student.setId(studentId);
			student.setStudentEmail(studentRequest.getStudentEmail());
			student.setStudentGrade(studentRequest.getStudentGrade());
			student.setStudentName(studentRequest.getStudentName());
			student.setStudentPhno(studentRequest.getStudentPhno());
			
			Student student2 = repo.save(student);
			
			StudentResponse response = new StudentResponse();
			response.setId(student2.getId());
			response.setStudentGrade(student2.getStudentGrade());
			response.setStudentName(student2.getStudentName());
			
			 
			structure.setStatus(HttpStatus.CREATED.value());
			structure.setMessage("The Data Got updated Successfully..!");
			structure.setData(response);
			return new ResponseEntity<ResponseStructure<StudentResponse>>(structure,HttpStatus.CREATED);


		}
		else {
			
			throw new StudentNotFoundByIdException("Entered Student Id is not Found to Update");
		}

		
	}

	@Override
	public ResponseEntity<ResponseStructure<StudentResponse>> deleteData(int studentId) {
		Optional<Student> optional= repo.findById(studentId);
		ResponseStructure<StudentResponse> structure  = new ResponseStructure<StudentResponse>();
		if(optional.isPresent())
		{
			Student student = optional.get();
			StudentResponse response = new StudentResponse();
			response.setId(student.getId());
			response.setStudentGrade(student.getStudentGrade());
			response.setStudentName(student.getStudentName());
			repo.delete(student);
			
			

			structure.setStatus(HttpStatus.CREATED.value());
			structure.setMessage("The data Got Deleted Succesfully..!");
			structure.setData(response);
			
			return  new ResponseEntity<ResponseStructure<StudentResponse>>(structure,HttpStatus.OK);

		}

		else 
		{
			throw new StudentNotFoundByIdException("The Id is not Found");
		}
		
	}

	@Override
	public ResponseEntity<ResponseStructure<StudentResponse>> findData(int studentId) {
		ResponseStructure<StudentResponse> structure = new ResponseStructure<StudentResponse>();
		Optional<Student> optional = repo.findById(studentId);
		if(optional.isPresent())
		{
			Student student = optional.get();
			StudentResponse response = new StudentResponse();
			response.setId(student.getId());
			response.setStudentGrade(student.getStudentGrade());
			response.setStudentName(student.getStudentName());
			
			
			structure.setMessage("The data got fetched "+student.getStudentEmail()+"/n"+student.getStudentName());
			structure.setStatus(HttpStatus.CREATED.value());
			structure.setData(response);
			return new ResponseEntity<ResponseStructure<StudentResponse>>(structure,HttpStatus.OK);
		}
		else
		{
			throw new StudentNotFoundByIdException("Cannot Find the Enter Student data");

		}


	}

	@Override
	public ResponseEntity<ResponseStructure<List<StudentResponse>>> findAllData() {

		List<Student> students = (List<Student>) repo.findAll();
		List<StudentResponse> studentResponse = new ArrayList<StudentResponse>();
		
		for(Student student : students){
			StudentResponse ele = new StudentResponse();
			ele.setId(student.getId());
			ele.setStudentName(student.getStudentName());
			ele.setStudentGrade(student.getStudentGrade());
			studentResponse.add(ele);
			
		}
				
		
		
		ResponseStructure<List<StudentResponse>> structure = new ResponseStructure<List<StudentResponse>>();
		structure.setData(studentResponse);
		structure.setMessage("Datas Got Retrived Succesfully..!");
		structure.setStatus(HttpStatus.CREATED.value());
		
		
	
		
		
		return new ResponseEntity<ResponseStructure<List<StudentResponse>>>(structure,HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ResponseStructure<StudentResponse>> findByEmail(String studentEamail) {
		
			Student student= repo.findByStudentEmail(studentEamail);
			
			if(student!=null)
			{
				StudentResponse response = new StudentResponse();
				response.setId(student.getId());
				response.setStudentGrade(student.getStudentEmail());
				response.setStudentName(student.getStudentName());
				
				ResponseStructure<StudentResponse> structure = new ResponseStructure<StudentResponse>();
				structure.setData(response);
				structure.setMessage("Student Found Based on Email");
				structure.setStatus(HttpStatus.FOUND.value());;
				
				return new ResponseEntity<ResponseStructure<StudentResponse>>(structure,HttpStatus.OK);
			}
			
			else
			{
				throw new StudentNotFoundByEmail("Student Not Found by entered Email");
			}
		
		
		
		
	}

	@Override
	public ResponseEntity<ResponseStructure<StudentResponse>> findByPhNo(long phNo) {
		
		Student student = repo.findByStudentPhno(phNo);
		
		if(student!=null)
		{
			StudentResponse response = new StudentResponse();
			response.setStudentName(student.getStudentName());
			response.setId(student.getId());
			response.setStudentGrade(student.getStudentGrade());
			
			ResponseStructure<StudentResponse> structure = new ResponseStructure<StudentResponse>();
			structure.setData(response);
			structure.setMessage("Student data Found");
			structure.setStatus(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<StudentResponse>>(structure,HttpStatus.FOUND);
		}
		else
		{
			throw new StudentNotFoundByPhno("Student Not Found in this Number");
		}
		
	}

	@Override
	public ResponseEntity<ResponseStructure<List<String>>> findEmailByGrade(String grade) {
		
		
	 List<String> emails= repo.getAllEmailByGrade(grade);
	 if(emails.isEmpty()){
	
		
		 throw new NoEmailFouundOnThisGrade("No Student Email Found in this Grade "+grade);
		
	}
	 else
	 {
		 
		 ResponseStructure<List<String>> structure = new ResponseStructure<List<String>>();
		 structure.setData(emails);
		 structure.setMessage("These are the Students Present in " +grade);
		 structure.setStatus(HttpStatus.CREATED.value());
		 
		 return new ResponseEntity<ResponseStructure<List<String>>>(structure,HttpStatus.OK);
		 
	 }

	}

}
