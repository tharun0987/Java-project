package com.studentdadabase.StudentDataBaseManagement.exceptions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.studnetdatabase.StudentDataBaseManagement.utilll.ErrorStructure;

@RestControllerAdvice
public class ApplicationExceptionHandler extends ResponseEntityExceptionHandler{


	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {

		List<ObjectError> allerrors = ex.getAllErrors();
		
		Map<String, String> errors = new HashMap<String,String>();

		for(ObjectError error: allerrors)
		{
			FieldError fieldError = (FieldError)error;
			String message =	fieldError.getDefaultMessage();
			String field = fieldError.getField();
			errors.put(field, message);
			
		}
		
		return new ResponseEntity<Object>(errors,HttpStatus.BAD_REQUEST);

	}


	@ExceptionHandler
	public ResponseEntity<ErrorStructure> studentNotFoundByid(StudentNotFoundByIdException e)
	{
		ErrorStructure structure = new ErrorStructure();
		structure.setMessage(e.getMessage());
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		structure.setRootCause("The Student is Not present with the Requested Id ..!!");


		return new ResponseEntity<ErrorStructure>(structure,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler
	public ResponseEntity<ErrorStructure> emailnotFoundByGrade(NoEmailFouundOnThisGrade e)
	{
		ErrorStructure structure = new ErrorStructure();
		structure .setMessage(e.getMessage());
		structure.setRootCause("No email Fouund on this Grade");
		structure.setStatus(HttpStatus.NOT_FOUND.value());

		return new ResponseEntity<ErrorStructure>(structure,HttpStatus.NOT_FOUND);
	}
	
	public ResponseEntity<ErrorStructure> phnoNotFound(StudentNotFoundByPhno e)
	{
		ErrorStructure structue = new ErrorStructure();
		structue.setMessage(e.getMessage());
		structue.setRootCause("Student Not Fouund ");
		structue.setStatus(HttpStatus.NOT_FOUND.value());
		
		return new ResponseEntity<ErrorStructure> (structue,HttpStatus.NOT_FOUND);
		
		
	}
	@ExceptionHandler
	public ResponseEntity<ErrorStructure> StudentNotFoundByEmail(StudentNotFoundByEmail e)
	{
		ErrorStructure structure = new ErrorStructure();
		structure.setMessage(e.getMessage());
		structure.setStatus(HttpStatus.NOT_FOUND.value());
		structure.setRootCause("Cannot find the Student by this Email");

		return new ResponseEntity<ErrorStructure>(structure,HttpStatus.NOT_FOUND);


	}
}
