package com.studnetdatabase.StudentDataBaseManagement.utilll;

public class ErrorStructure {
	
	private int Status;
	private String message;
	private String rootCause;
	
	
	public int getStatus() {
		return Status;
	}
	public void setStatus(int status) {
		Status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getRootCause() {
		return rootCause;
	}
	public void setRootCause(String rootCause) {
		this.rootCause = rootCause;
	}
	
	

}
